﻿var app = angular.module('app', ['ngResource']);
